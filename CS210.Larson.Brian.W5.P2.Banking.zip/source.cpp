#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <windows.h>

using namespace std;


/*
Brian Larson
CS210 - 24EW4
Week 5 Project 2
Airgead Banking
*/
/*
bool WriteData(string p_fileName, string p_data){
	ofstream outFS;
	outFS.open(p_fileName);
	if (!outFS.is_open()) {
		cout << "Error opening file: " << p_fileName << endl;
		system("PAUSE");
		return false;
	}
	outFS << p_data;
	outFS.close();
	return true;
}
string ReadData(string p_fileName) {
	ifstream inFS;
	inFS.open(p_fileName);
	if (!inFS.is_open()) {
		cout << "Error opening file: " << p_fileName << endl;
		system("PAUSE");
		return "Error";
	}
	string returnData = "";
	string readbuffer;
	while (!inFS.eof()) {
		getline(inFS, readbuffer);
		returnData += readbuffer + '\n';
	}
	inFS.close();
	return returnData;
}
*/
string formatMoney(float p_value) {
	string result = "$" + to_string(int(p_value)) + ".";
	int mantissa = int(round(p_value * 100))%100;
	result += ((mantissa < 10) ? "0" : "") + to_string(mantissa);
	return result;
}

void ShowCompoundInterest(float p_initialAmount, float p_monthlyDeposit = 0, float p_annualInterest = 5, int p_numYears = 5) {
	
	int colW = 12;
	int reportColW = 70;
	float interest;
	float closing;
	float yearEarnedInterest = 0;
	float runningTotal = p_initialAmount;
	// Build Report Header
	string header = "Balance and Interest With";
	header += ((p_monthlyDeposit == 0) ? "out" : "");
	header += " Additional Monthly Deposits";
	// Center header and format column heads
	cout << setw(((reportColW+1) -header.length())/2+header.length()) << header << endl;
	// ==== Divider
	cout << setw(reportColW+1) << setfill('=') << "=\n" << setfill(' ');
	// Column Heads
	cout << setw(10) << "Year" << setw(25) << "Year End Balance" << setw(30) << "Year End Earned Interest" << endl;
	// ---- Divider
	cout << setw(reportColW+1) << setfill('-') << "-\n" << setfill(' ');

	// calculate
	for (int i = 0; i < p_numYears; i++) {  // Calculate per year
		for (int j = 0; j < 12; j++) {		// calculate monthly figures
			interest = (runningTotal + p_monthlyDeposit) * ((p_annualInterest / 100) / 12);
			yearEarnedInterest += interest; 
			closing = runningTotal + interest + p_monthlyDeposit;
			// Monthly compunding results
			// cout << setw(colW) << runningTotal << setw(colW) << p_monthlyDeposit << setw(colW) << interest << setw(colW) << closing << endl;
			runningTotal = closing;
		}
		
		cout << setw(10) << i+1 << setw(25) << formatMoney(runningTotal) << setw(30) << formatMoney(yearEarnedInterest) << endl << endl;
		// reset year's interest
		yearEarnedInterest = 0;
	}
}

void InterestCalculator() {
	// variables
	float initialAmount;
	float monthlyDeposit;
	float annualInterest;
	int numYears;
	// text formatting
	cout << fixed << setprecision(2);
	// Data Input
	cout << "Data Input" << endl;
	cout << "Initial Investment Amount: $";
	cin >> initialAmount;
	cout << "Monthly Deposit: $";
	cin >> monthlyDeposit;
	cout << "Annual Interest: %";
	cin >> annualInterest;
	cout << "Number of Years: ";
	cin >> numYears;
	// Show results
	ShowCompoundInterest(initialAmount, monthlyDeposit, annualInterest, numYears);
	ShowCompoundInterest(initialAmount, 0, annualInterest, numYears);
}

void main() {

	int choice = -1;
	// Looping ops menu
	// enter 0 (zero) to exit
	while (choice != 0) {
		cout << "Banking App" << endl;
		cout << "1 - Interest Caculator" << endl;
		cout << "0 - Exit" << endl;
		cin >> choice;
		switch (choice) {
		case 1: 
			InterestCalculator();
			break;
		case 0:
			cout << "Thank you for using our app." << endl;
			break;
		default:
			cout << "Please enter a valid number." << endl;
			Sleep(1000);
			system("CLS");
		}
	}			
}